from django.shortcuts import render
from .models import Blog
from django.http import HttpResponse


# Create your views here.

def blogview(request):
    blog = Blog.objects.all()
    # doc = blog[0].description
    context = {
        "pro": blog
    }
    return render(request, 'index.html', context)
