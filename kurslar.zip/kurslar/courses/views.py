from django.shortcuts import render
from .serializers import KursSerializer, BlogSerializer
from .models import Kurs, Blog
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet


# Create your views here.

class KursViewSet(ModelViewSet):
    queryset = Kurs.objects.all()
    serializer_class = KursSerializer


class BlogViewSet(ModelViewSet):
    queryset = Blog.objects.all()
    serializer_class = BlogSerializer

    def get_serializer(self, *args, **kwargs):
        if isinstance(kwargs.get("data", {}), list):
            kwargs["many"] = kwargs.get("many", True)
        return super(BlogViewSet, self).get_serializer(*args, **kwargs)
