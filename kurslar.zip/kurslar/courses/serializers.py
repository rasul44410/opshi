from rest_framework.serializers import ModelSerializer
from .models import Kurs, Blog


class KursSerializer(ModelSerializer):
    class Meta:
        model = Kurs
        fields = "name", "parent", "id"


class BlogSerializer(ModelSerializer):
    class Meta:
        model = Blog
        fields = "__all__"

