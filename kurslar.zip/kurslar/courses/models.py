from django.db import models


class Kurs(models.Model):
    parent = models.ForeignKey('Kurs', verbose_name='Otasi', on_delete=models.CASCADE,
                               blank=True, null=True)
    name = models.CharField(verbose_name="Kurs nomi", max_length=30)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Kurs'
        verbose_name_plural = 'Kurslar'


class Blog(models.Model):
    kurs = models.ForeignKey('Kurs', on_delete=models.CASCADE, verbose_name='Kurs haqida')
    name = models.CharField(verbose_name="Blog nomi", max_length=30000)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Blog'
        verbose_name_plural = 'Bloglar'

