from rest_framework.routers import SimpleRouter
from django.urls import path, include
from .views import KursViewSet, BlogViewSet

router = SimpleRouter()
router.register('kurs', KursViewSet)
router.register('blog', BlogViewSet)


urlpatterns = [
    # path('kurs', )
]
