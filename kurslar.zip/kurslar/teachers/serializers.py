from rest_framework.serializers import ModelSerializer
from .models import teacher


class TeacherSerializer(ModelSerializer):
    class Meta:
        model = teacher
        fields = "__all__"


