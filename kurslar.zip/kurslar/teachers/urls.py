from rest_framework.routers import SimpleRouter
from django.urls import path, include
from .views import TeacherViewSet

router = SimpleRouter()

router.register('malim', TeacherViewSet)

urlpatterns = [
]
