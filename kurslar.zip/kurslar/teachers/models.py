from django.db import models


# Create your models here.
class teacher(models.Model):
    name = models.CharField(verbose_name="O'/qituvchining to'liq ishm familiyasi",max_length=200)
    about = models.CharField(verbose_name='about teachers', max_length=5000)
    phone = models.CharField(verbose_name='Telefon raqami', null=True, blank=False, max_length=13)

    def __str__(self):
        return self.name

class contact(models.Model):
    teacher = models.ForeignKey('teacher', on_delete=models.CASCADE, verbose_name='uqituvchi')
    about = models.CharField(verbose_name='about teachers', max_length=5000)
    phone = models.CharField(verbose_name='Telefon raqami', null=True, blank=False, max_length=13)
    addres = models.CharField(verbose_name='manzil', null=True, blank=False, max_length=150)

    def __str__(self):
        return self.teacher
