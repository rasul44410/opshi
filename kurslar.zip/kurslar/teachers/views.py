from django.shortcuts import render
from .serializers import TeacherSerializer
from .models import teacher
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet


# Create your views here.

class TeacherViewSet(ModelViewSet):
    queryset = teacher.objects.all()
    serializer_class = TeacherSerializer

