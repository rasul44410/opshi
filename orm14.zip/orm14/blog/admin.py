from django.contrib import admin
from .models import *


@admin.register(Blog)
class BlogAdmin(admin.ModelAdmin):
    date_hierarchy = 'entry__pub_date'
    list_display = 'upper_cese_name',
    search_fields = 'name',


@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = 'name', 'email'
    list_display_links = 'email',
    search_help_text = '⭕️Izla bolakay⭕️'
    search_fields = 'name', 'email'


@admin.register(Entry)
class EntryAdmin(admin.ModelAdmin):
    list_display = 'age',
    ordering = '-id'
    # date_hierarchy = 'pub_date'
    # list_display = 'blog', 'headline', 'pub_date', 'view_birth_date',
    # search_fields = 'headline',
    # list_filter = 'authors', 'blog',
    fieldsets = (
        ("Egalar", {
            'fields': ('blog', 'authors',),
            'description': "Qonday😶‍️😶️😶‍👋🏻",
            'classes': ('collapse',),
        }),
        ("Middle info", {
            'fields': ('headline', 'body_text',),
            'classes': ('collapse',),
        }),
        ("Numeric info", {
            'fields': (('pub_date', 'mod_date',), 'number_of_pingbacks', 'rating'),
            'classes': ('collapse',),
        })

    )

    # exclude = 'body_text',

# admin.site.register(Entry, EntryAdmin)


@admin.register(Person)
class PersonAdmin(admin.ModelAdmin):
    list_display = ('name', 'birth_date_view')
    list_display = ('first_name', 'last_name', 'colored_name')
