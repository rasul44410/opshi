from django.shortcuts import render
from django.http import HttpResponse
from .models import *

def test(request,id):
    # blog = Blog.objects.all()
    blog = Blog.objects.raw("SELECT * FROM blog_blog ")
    print(blog[0].tagline)
    print(blog.query)
    return HttpResponse(f"Salom  {blog[0]}")



