from datetime import date
from django.contrib import admin
from django.db import models
from datetime import datetime
from django.utils.html import format_html


class Blog(models.Model):
    name = models.CharField(verbose_name="Blog nomini yozing😂🤢", max_length=100)
    tagline = models.TextField(verbose_name="Blog uchun ilova😂🤢", help_text="Siz bu bo'limga "
                                                                            "blog matnini toliq yozasiz🤮😂🤢!")

    def __str__(self):
        return self.name

    @admin.display  # (description='Name')
    def upper_cese_name(self):
        return ("%s --->>> %s" % (self.name, self.tagline)).upper()


class Author(models.Model):
    name = models.CharField(max_length=200)
    email = models.EmailField()

    def __str__(self):
        return self.name

    @admin.display  # (description='Name')
    def upper_cese_name(self):
        return ("%s --->>> %s" % (self.name, self.tagline)).upper()


class Entry(models.Model):
    blog = models.ForeignKey(Blog, on_delete=models.PROTECT, null=True)
    headline = models.CharField(max_length=255)
    body_text = models.TextField()
    pub_date = models.DateField()
    mod_date = models.DateField(default=date.today)
    authors = models.ManyToManyField(Author)
    number_of_comments = models.IntegerField(default=0)
    number_of_pingbacks = models.IntegerField(default=0)
    rating = models.IntegerField(default=5)

    def __str__(self):
        return self.headline

    @admin.display(empty_value='Days')
    def age(self):
        date_format = "%Y-%m-%d"
        a = datetime.strptime(str(datetime.now().date()), date_format)
        b = datetime.strptime(str(self.pub_date), date_format)
        date = a - b

        return date.days // 365


class Person(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    color_code = models.CharField(max_length=6)

    @admin.display
    def colored_name(self):
        return format_html(
            '<span style="color: #{};">{} {}</span>',
            self.color_code,
            self.first_name,
            self.last_name,
        )
