from .views import HelloApiView
from django.urls import path

urlpatterns = [
    path('hello-world', HelloApiView.as_view(), name='hello-world'),
]