from rest_framework.views import APIView
from rest_framework.response import Response

# Create your views here.

class HelloApiView(APIView):

    def get(self, request):
        return Response(data={'habar' : "Hello world"})

    def post(self, request):
        message = f"Hello {request.data['ism']}"
        return Response(data={"message" : message})