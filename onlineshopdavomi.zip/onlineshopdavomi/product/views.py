from django.shortcuts import render
from .serializers import CategorySerializer, ProductSerializer
from .models import Product, Category
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet


# Create your views here.

class CategoryViewSet(ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class ProductViewSet(ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
