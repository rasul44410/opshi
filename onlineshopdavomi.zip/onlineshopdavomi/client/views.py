from django.shortcuts import render
from .serializers import ClientSerializer
from .models import Client
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet


# Create your views here.

class ClientViewSet(ModelViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer

