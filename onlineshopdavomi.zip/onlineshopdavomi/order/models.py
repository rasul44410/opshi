from django.db import models


class Order(models.Model):
    ORDER_STATUS = (
        ("created", "Yaratilgan"),
        ("accepted", "Tasdiqlangan"),
        ("completed", "Tugallangan"),
        ("canceled", 'Rad etilgan'),
    )

    client = models.ForeignKey("client.Client", verbose_name="Xaridor", on_delete=models.PROTECT)
    created_at = models.DateTimeField(verbose_name="Yaratilgan vaqti", auto_now_add=True)
    status = models.CharField(verbose_name="Maxsulot Xolati", max_length=255, choices=ORDER_STATUS)
    total = models.DecimalField(verbose_name="Narxi", max_digits=17, decimal_places=2)

    def str(self):
        return self.created_at.strftime("%d-%m-%Y")

    class Meta:
        verbose_name = "Zakaz"
        verbose_name_plural = "Zakazlar"


class OrderItem(models.Model):
    order = models.ForeignKey("Order", verbose_name="Zakaz", on_delete=models.PROTECT)
    product = models.ForeignKey("product.Product", verbose_name="Maxsulot", on_delete=models.PROTECT)
    price = models.DecimalField(verbose_name="Narxi", max_digits=17, decimal_places=2)
    count = models.IntegerField(verbose_name="Soni")
    total = models.DecimalField(verbose_name="Summasi", max_digits=17, decimal_places=2)

    def str(self):
        return self.product.name

    class Meta:
        verbose_name = "Zakaz birligi"
        verbose_name_plural = "Zakaz birliklari"
