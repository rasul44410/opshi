from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import OrderViewSet, OrderItemViewSet

routers = DefaultRouter()
routers.register('Order', OrderViewSet)
routers.register('OrderItem', OrderItemViewSet)


urlpatterns = [
    path('', include(routers.urls))
]
