from django.shortcuts import render
from .serializers import WarehouseNameSerializer, WarehouseProductSerializer
from .models import WarehouseName, WarehouseProduct
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet


# Create your views here.

class WarehouseNameViewSet(ModelViewSet):
    queryset = WarehouseName.objects.all()
    serializer_class = WarehouseNameSerializer


class WarehouseProductViewSet(ModelViewSet):
    queryset = WarehouseProduct.objects.all()
    serializer_class = WarehouseProductSerializer
