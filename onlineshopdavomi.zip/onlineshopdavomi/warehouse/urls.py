from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import WarehouseNameViewSet, WarehouseProductViewSet

routers = DefaultRouter()
routers.register('Baza nomi', WarehouseNameViewSet)
routers.register('Bazadaki produktla', WarehouseProductViewSet)


urlpatterns = [
    path('', include(routers.urls))
]
