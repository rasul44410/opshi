from rest_framework.serializers import ModelSerializer
from .models import WarehouseName, WarehouseProduct


class WarehouseNameSerializer(ModelSerializer):
    class Meta:
        model = WarehouseName
        fields = "__all__"


class WarehouseProductSerializer(ModelSerializer):
    class Meta:
        model = WarehouseProduct
        fields = "__all__"
