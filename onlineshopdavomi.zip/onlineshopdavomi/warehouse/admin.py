from django.contrib import admin
from .models import WarehouseName, WarehouseProduct

# Register your models here.

admin.site.register([WarehouseName, WarehouseProduct])
