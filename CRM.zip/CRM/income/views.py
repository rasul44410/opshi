from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from .models import Income, IncomeItem
from .serializers import IncomeSerializer, IncomeItemSerializer


class IncomeViewSet(ModelViewSet):
    queryset = Income.objects.all()
    serializer_class = IncomeSerializer


class IncomeItemViewSet(ModelViewSet):
    queryset = IncomeItem.objects.all()
    serializer_class = IncomeItemSerializer
