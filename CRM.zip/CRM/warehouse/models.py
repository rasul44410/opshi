from django.db import models


class Warehouse(models.Model):
    name = models.CharField(verbose_name="Baza nomi", max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Baza"
        verbose_name_plural = "Bazalar"


class WarehouseProduct(models.Model):
    warehouse = models.ForeignKey("Warehouse", verbose_name="Baza", on_delete=models.PROTECT)
    product = models.ForeignKey("product.Product", verbose_name="Maxsulot nomi", on_delete=models.PROTECT)
    count = models.IntegerField(verbose_name="Soni")
    self_price = models.DecimalField(verbose_name="Maxsulotning tan narxi", max_digits=17, decimal_places=2)

    def __str__(self):
        return self.product.name

    class Meta:
        verbose_name = "Bazadagi maxsulot"
        verbose_name_plural = "Bazadagi maxsulotlar"
    