from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from .models import Warehouse, WarehouseProduct
from .serializers import WarehouseSerializer, WarehouseProductSerializer


class WarehouseViewSet(ModelViewSet):
    queryset = Warehouse.objects.all()
    serializer_class = WarehouseSerializer


class WarehouseProductViewSet(ModelViewSet):
    queryset = WarehouseProduct.objects.all()
    serializer_class = WarehouseProductSerializer

