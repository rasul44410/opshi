from .album import Album
from .song import Song
from .artist import Artist