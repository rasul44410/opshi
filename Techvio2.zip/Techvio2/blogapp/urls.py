from django.urls import path
from home.views import *
from blogapp.views import blogview

urlpatterns = [
    path('index/', index),
    path('blog/',blogview, name='blogview')
]

