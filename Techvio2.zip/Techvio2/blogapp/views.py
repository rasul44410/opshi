from django.shortcuts import render
from .models import Blog
from django.http import HttpResponse


# Create your views here.

def blogview(request):
    blog = Blog.objects.filter(id=2)
    doc = blog[0].description
    print(doc)
    return HttpResponse(doc)
