from django.apps import AppConfig


class WerhouseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'werhouse'
