def phone_validator(value):
    if not len(value) == 13:
        raise ValueError("phone number is incorect")
    else:
        return True