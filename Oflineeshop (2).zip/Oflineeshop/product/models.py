from django.db import models


class Category(models.Model):
    objects = None
    parent = models.ForeignKey('Category', verbose_name='Otasi', on_delete=models.CASCADE,
                               blank=True, null=True)
    name = models.CharField(verbose_name="Categoriya nomi", max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Kategoriya'
        verbose_name_plural = 'Kategoriyalar'


class Product(models.Model):
    objects = None
    category = models.ForeignKey('Category', on_delete=models.CASCADE, verbose_name='Mahsulot Categoriyasi')
    name = models.CharField(verbose_name="Mahsulot nomi", max_length=300)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Maxsulot'
        verbose_name_plural = 'Maxsulotlar'