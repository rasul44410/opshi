from django.db import models


class WarehouseName(models.Model):
    name = models.CharField(verbose_name="Baza nomi", max_length=255)

    def __str__(self):
        return self.name


class WarehouseProduct(models.Model):
    warehous = models.ForeignKey('WarehouseName', verbose_name='Baza nomi', on_delete=models.CASCADE)
    product = models.ForeignKey('product.Product',verbose_name='Mahsulot nomi', on_delete=models.PROTECT, blank=False, null=False)
    narxi = models.IntegerField(verbose_name='mahsulot narxi')

    def __str__(self):
        return self.product
