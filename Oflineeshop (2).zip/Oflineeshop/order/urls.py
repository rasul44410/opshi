from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import OrderViewSet, OrderItemViewSet

routers = DefaultRouter()
routers.register('order', OrderViewSet)
routers.register('orderitem', OrderItemViewSet)

urlpatterns = [
    path('', include(routers.urls))
]
