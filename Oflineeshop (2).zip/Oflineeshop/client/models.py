from django.db import models

# Create your models here.
class Client(models.Model):
    ism = models.CharField(verbose_name="Xaridorning to'liq ism familiyasi", max_length=70)
    telfon = models.CharField(verbose_name="Telefon raqam", max_length=13)
