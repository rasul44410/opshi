from django.db import models


class Category(models.Model):
    parent = models.ForeignKey("Category", on_delete=models.CASCADE, verbose_name="Ota Kategoriya")
    name = models.CharField(verbose_name="Katigoria nomi", max_length=255, )


class Product(models.Model):
    category = models.ForeignKey('Category', on_delete=models.CASCADE, verbose_name="Maxsulot kategoriyasi", blank=True, null=True)
    name = models.CharField(verbose_name="Maxsulot nomi", max_length=300)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Kategorialar"
        verbose_name_plural = "Kategorialar"

